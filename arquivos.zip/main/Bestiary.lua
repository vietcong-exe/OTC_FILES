local beastWidget

local beastiaryUI = setupUI([[
MainWindow
  size: 500 300
  text: Bestiary
  font: verdana-11px-rounded
  visible: false
  @onEscape: self:hide()

  Label
    id: searchtxt
    anchors.right: parent.right
    margin-right: 165
    text-auto-resize: true
    text: Search:
    font: verdana-11px-rounded
    color: white
    anchors.top: parent.top
    margin-top: 10

  TextEdit
    id: searchbox
    anchors.right: parent.right
    margin-right: 5
    width: 150
    anchors.top: parent.top
    margin-top: 5

  ScrollablePanel
    padding: 1
    id: beastyPanel
    height: 200
    margin-right: 5
    anchors.top: prev.bottom
    margin-top: 10
    anchors.left: parent.left
    anchors.right: parent.right
    border: 1 black
    background-color: #282828
    vertical-scrollbar: scroll
    layout:
      type: verticalBox

  BotSmallScrollBar
    id: scroll
    anchors.top: prev.top
    anchors.bottom: prev.bottom
    anchors.right: parent.right
    step: 10
    pixels-scroll: true

]], g_ui.getRootWidget())


local beast = [[
Panel
  height: 60
  background-color: #282828

  UICreature
    id: creature
    image-source:
    size: 40 40
    old-scaling: true
    anchors.left: parent.left
    margin-left: 30
    anchors.top: parent.top
    margin-top: 5

  Label
    id: name
    anchors.top: prev.bottom
    anchors.horizontalCenter: prev.horizontalCenter
    font: verdana-11px-rounded
    text-align: center
    text-auto-resize: true

    

  Label
    id: lbltxt
    anchors.left: parent.left
    margin-left: 120
    text: DeathCount:
    text-auto-resize: true
    anchors.top: parent.top
    margin-top: 5
    font: verdana-11px-rounded

  Label
    id: deathCount
    anchors.top: prev.bottom
    margin-top: 10
    anchors.horizontalCenter: prev.horizontalCenter
    font: terminus-14px-bold
    color: red

  Label
    id: lbltxt2
    anchors.left: prev.right
    margin-left: 70
    text: FirstPosition:
    text-auto-resize: true
    anchors.top: parent.top
    margin-top: 5
    font: verdana-11px-rounded

  Label
    id: firstPosition
    anchors.top: prev.bottom
    margin-top: 5
    anchors.horizontalCenter: prev.horizontalCenter
    color: yellow
    text-auto-resize: true
    multiline: true
    font: verdana-11px-rounded

  Label
    id: lbltxt3
    anchors.left: prev.right
    margin-left: 70
    text: Loots:
    text-auto-resize: true
    anchors.top: parent.top
    margin-top: 5
    font: verdana-11px-rounded

  ScrollablePanel
    id: possibleLoots
    anchors.top: prev.bottom
    margin-top: 2
    size: 100 30
    vertical-scrollbar: scroll
    anchors.horizontalCenter: prev.horizontalCenter
    layout:
      type: verticalBox

  BotSmallScrollBar
    id: scroll
    anchors.top: prev.top
    anchors.bottom: prev.bottom
    anchors.right: prev.right
    step: 10
    pixels-scroll: true
    visible: false

]]
beastiaryUI:setId("bestiaryUI")
storage.beastiary = storage.beastiary or {}


local findInBeastiary = function(n)
    for _, beast in pairs(storage.beastiary) do
        if n == beast.name then
            return true
        end
    end
    return false
end


onCreatureAppear(function(c)
    if (c:isPlayer() or c:isNpc()) then return end
    if findInBeastiary(c:getName()) then return end
    table.insert(storage.beastiary, {name = c:getName(), outfit = c:getOutfit().type, pos = c:getPosition(), count = 0, loot = {}})
    displayBeastiary()
end)

onCreatureHealthPercentChange(function(creature, hp)
    if findInBeastiary(creature:getName()) and creature:getHealthPercent() <= 0 then
        for z, l in pairs(storage.beastiary) do
            if creature:getName() == l.name then
                l.count = l.count + 1
            end
        end
        displayBeastiary()
    end
end)



displayBeastiary = function()
    local search = beastiaryUI.searchbox:getText()
    beastiaryUI.beastyPanel:destroyChildren()
    for _, beasty in pairs(storage.beastiary) do
        if (beasty.name:lower():find(search)) then
            beastWidget = g_ui.loadUIFromString(beast, beastiaryUI.beastyPanel)
            beastWidget.creature:setOutfit({type = beasty.outfit})
            beastWidget.name:setText(beasty.name)
            beastWidget.deathCount:setText(beasty.count)
            beastWidget.firstPosition:setText("X: ".. beasty.pos.x.. "\nY: ".. beasty.pos.y)
            for _, loot1 in pairs(beasty.loot) do
                local label = g_ui.createWidget("UILabel", beastWidget.possibleLoots)
                label:setFont("verdana-9px")
                label:setText("- ".. loot1)
                label:setColor("white")
                label:setTextAutoResize(true)
            end
            if not beastWidget:isFirst() then
                beastWidget:setBorderWidthTop(1)
                beastWidget:setBorderColorTop("black")
            end
        end
    end
end



onTextMessage(function(mode, text)
    if not text:lower():find("loot") then return end
    local spl = text:split(":")
    for _, beast in pairs(storage.beastiary) do
        if spl[1]:lower():find(beast.name:lower()) then
            if spl[2]:find(",") then
                local loots = spl[2]:split(",")
                for _, loot in pairs(loots) do
                    local realLoot = loot:gsub("%.$", "")
                    if not table.find(beast.loot, realLoot) then
                        table.insert(beast.loot, realLoot)
                    end
                end
            else
                local realLoot = spl[2]:gsub("%.$", "")
                if not realLoot:lower():find("nothing") then
                    if not table.find(beast.loot, realLoot) then
                        table.insert(beast.loot, realLoot)
                    end
                end
            end
        end
    end
    displayBeastiary()
end)

displayBeastiary()



beastiaryUI.searchbox.onTextChange = function(s, text)
    displayBeastiary()
end