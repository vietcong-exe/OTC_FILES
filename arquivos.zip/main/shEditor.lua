storage.custom.Editor = storage.custom.Editor or ""
setDefaultTab("Scripts")
local shadow_editor = setupUI([[
MainWindow
  size: 500 500
  font: verdana-11px-rounded
  color: white
  padding: 0
  image-source:
  @onEscape: self:hide()
  visible: false
  border: 1 white

  Label
    id: background
    anchors.fill: parent
    padding: 0
    background-color: black
    opacity: 0.7

  Label
    id: title
    anchors.fill: parent
    padding: 0 
    text: Scripts Editor
    font: verdana-11px-rounded
    icon: /bot/Wodahs_1.0/main/icon
    icon-align: topLeft
    text-offset: 35 6
    icon-offset: 15 5

    Label
      id: marshadow
      size: 50 50
      anchors.right: parent.right
      anchors.bottom: parent.bottom
      image-source: /bot/Wodahs_1.0/main/gif
      opacity: 0.6
      margin-right:20
      margin-bottom: 42

  TextEdit
    id: scripts
    anchors.fill: parent
    multiline: true
    font: terminus-14px-bold
    color: green
    margin-top: 25
    margin-left: 15
    margin-right: 15
    margin-bottom: 40
    border: 1 gray
    image-source:
    pixel-scroll: true
    vertical-scrollbar: contentScrollBar
    layout:
      type: verticalBox
      align-bottom: true



  VerticalScrollBar
    id: contentScrollBar
    anchors.top: scripts.top
    anchors.bottom: scripts.bottom
    anchors.right: scripts.right
    pixels-scroll: 2
    margin-right: 1
    image-source:
    color: #c874b2
    opacity: 0.5

  Button
    anchors.right: parent.right
    anchors.bottom: parent.bottom
    id: save
    margin-bottom: 10
    margin-right: 15
    text: SAVE
    image-color: black

  Button
    anchors.right: prev.left
    anchors.bottom: parent.bottom
    id: close
    margin-bottom: 10
    margin-right: 15
    text: CLOSE
    image-color: red
]], g_ui.getRootWidget())
shadow_editor:setId("shEditor")

shadow_editor.scripts:setText(storage.custom.Editor or "")
shadow_editor.close.onClick = function()
    shadow_editor:hide()
end
shadow_editor.save.onClick = function()
    storage.custom.Editor = shadow_editor.scripts:getText()
    reload()
    shadow_editor:hide()
end

for _, scripts in pairs({storage.custom.Editor}) do
  if type(scripts) == "string" and scripts:len() > 3 then
    local status, result = pcall(function()
      assert(load(scripts, "shadow_editor"))()
    end)
    if not status then 
      error("shEditor:\n" .. result)
    end
  end
end

