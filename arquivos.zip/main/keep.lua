keepTarget = {}

local message = modules.game_bot.message;

info = function(text) return message("info", tostring(text)) end
warn = function(text) return message("warn", tostring(text)) end
warning = warn
error = function(text) return message("error", tostring(text)) end
warning = function() 
    return  
end

table.recursiveFindByKey = function(t, k, parent, readed)
	readed = readed or {};
	parent = parent or 'modules'

	for key, value in pairs(t) do
		if k == key then return value end
		if type(value) == 'table' then
			local index = parent .. '.' .. key
			if (not readed[index]) then
				readed[index] = true
				local find = table.recursiveFindByKey(value, k, key, readed)
				if find then return find end
			end
		end
	end
	
end

table.recursiveMatchKey = function(t, k, parent, readed)
	readed = readed or {};
	parent = parent or 'modules';
	k = k:lower()
	for key, value in pairs(t) do
		key = tostring(key):lower()
		if key:match(k) then return value end
		if type(value) == 'table' then
			local index = parent .. '.' .. key
			if (not readed[index]) then
				readed[index] = true
				local find = table.recursiveMatchKey(value, k, key, readed)
				if find then return find end
			end
		end
	end
end



g_app = table.recursiveFindByKey(modules, 'g_app')

keepTarget.isMobile = g_app.isMobile()

if not keepTarget.isMobile then
	keepTarget.keyCancel = "Escape"
else
	keepTarget.keyCancel = "F2"
end


function Creature:isVisible()
	local creaturePos = self:getPosition()
	if (not creaturePos) then return false end
	local pos = pos()
	if (pos.z == creaturePos.z) then
		return true
	end
end

keepTarget.g_i = table.recursiveMatchKey(modules, 'game_interface')

keepTarget.p_m = table.recursiveMatchKey(modules, 'processMouseAction')


local rec_ch_by_id = {"r", "e", "c", "u", "r", "s", "i", "v", "e", "G", "e", "t", "C", "h", "i", "l", "d", "B", "y", "I", "d"};
rec_ch_by_id = table.concat(rec_ch_by_id);
battlePanel = "battlePanel = g_ui.getRootWidget():%s('battlePanel')";
battlePanel = battlePanel:format(rec_ch_by_id);
loadstring(battlePanel)();

keepTarget.battlePanel = battlePanel;

keepTarget.getSpectators = function()
	local specs = getSpectators();
	if (#specs == 0) then
		local tiles = g_map.getTiles(posz());
	
		for _, tile in ipairs(tiles) do
			for _, spec in ipairs(tile:getCreatures()) do
				table.insert(specs, spec);
			end
		end
		
	end
	return specs;
end


keepTarget.checkAttack = function()
	keepTarget.g_i.resetLeftActions()
	keepTarget.g_i.gameLeftActions:getChildById("attack").image:setChecked(true);
end

keepTarget.doAttack = function(creature)
	if (keepTarget.getAttackingCreature() == creature) then return end
	local creaturePos = creature:getPosition()
	if (not creaturePos or pos().z ~= creaturePos.z) then return end
	if (not keepTarget.isMobile) then
		keepTarget.p_m(creaturePos, 2, creaturePos, creature, creature, creature, creature)
	else
		keepTarget.checkAttack()
		keepTarget.p_m(creaturePos, 1, creaturePos, creature, creature, creature, creature)
	end
end

keepTarget.searchWithinVariables = function() -- forEach function that contains "getatt", will try to get the creature
	for key, func in pairs(g_game) do
		key = key:lower();
		if (key:match("getatt") and type(func) == 'function') then
			local result = func();
			if (result) then
				if (result:isPlayer() or result:isMonster()) then
					return result;
				end
			end
		end
	end
end

local ATTACKING_COLORS = {'#FF8888', '#FF0000'};

keepTarget.getAttackingCreature = function()
	local pos = pos();
	for i, root in ipairs(g_ui.getRootWidget():recursiveGetChildren()) do
		if root:getId() == "battlePanel" then
			for _, child in ipairs(root:getChildren()) do
				local creature = child.creature
				if (creature) then
					local creaturePos = creature:getPosition();
					if (creaturePos and creaturePos.z == pos.z) then
						if (table.find(ATTACKING_COLORS, child.color)) then
							return creature;
						end
					end
				end
			end
		end
	end
	return keepTarget.searchWithinVariables();
end

keepTarget.getCreatureById = function(id)
	local pos = pos()
	for _, creature in pairs(keepTarget.getSpectators()) do
		if (creature:getId() == id) then
			return creature;
		end
	end
end


function keepTarget:resetStorage()
	self.storageId = nil
	self.timeDelay = nil
	g_game.cancelAttack()
end

keepTarget.macro = macro(1, "Attack Target", function()
	if modules.corelib.g_keyboard.isKeyPressed(keepTarget.keyCancel) then
		return keepTarget:resetStorage()
	end
	local target = keepTarget.getAttackingCreature()
	if target then
		if target:isNpc() then return end
		if keepTarget.storageId ~= target:getId() then
			keepTarget.storageId = target:getId()
		end
	elseif (keepTarget.storageId and not isInPz()) then
		local findCreature = keepTarget.getCreatureById(keepTarget.storageId)
		if findCreature then
			keepTarget.attackingCreature = findCreature:getId()
				if (keepTarget.attackingCreature ~= keepTarget.storageId) then return end
				if g_game.getAttackingCreature() then return end
				keepTarget.doAttack(findCreature)
		end
	end
end)