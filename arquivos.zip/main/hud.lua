-- target elfbot clone
storage.custom.hud = storage.custom.hud or {}
local st_hud = storage.custom.hud
st_hud.deathList = st_hud.deathList or {}
local tUI = setupUI([[
Label
  text-auto-resize: true
  font: verdana-11px-rounded
  color: white
  opacity: 0.9
  phantom: true
  anchors.left: parent.left
  anchors.top: parent.top
  margin-top: 50
  margin-left: 5
  visible:false
]], g_ui.getRootWidget())
tUI:setId("tUI")
tUI:setColoredText({"Target:  ", "white", "~", "red"})

onAttackingCreatureChange(function(creature, oldcreature)
  local atual
  if creature then
    atual = creature:getName()
  else
    atual = "~"
  end

  tUI:setColoredText({"Target:  ", "white", atual, "red"})
end)

-- stand time elfbot clone

local stUI = setupUI([[
Label
  text-auto-resize: true
  visible:false
  font: verdana-11px-rounded
  color: white
  opacity: 0.9
  phantom: true
  anchors.left: parent.left
  anchors.top: parent.top
  margin-top: 70
  margin-left: 5
  text: standTime:  ~
]], g_ui.getRootWidget())
stUI:setId("stUI")
local function getStand()
  local ui = g_ui.getRootWidget():recursiveGetChildById("stUI")
  ui:setText("standTime:  ".. standTime()/100)
end

macro(1, getStand)


local deathList = setupUI([[
Panel
  phantom: true
  anchors.left: parent.left
  anchors.top: parent.top
  margin-top: 100
  margin-left: 5
  size: 300 400
  visible: false

  Label
    text: DeathList:
    font: verdana-11px-rounded
    anchors.left: parent.left
    anchors.top: parent.top
    text-auto-resize:true

  ScrollablePanel
    id: deathList
    anchors.top: prev.bottom
    margin-top: 10
    anchors.left: parent.left
    anchors.bottom: parent.bottom
    anchors.right: parent.right
    layout:
      type: verticalBox 
]], g_ui.getRootWidget())

deathList:setId("deathList")
local playerUI = [[
Label
  text-auto-resize: true
  font: verdana-9px
  color: red
]]

local function findInDeathList(n)
  for _, i in pairs(st_hud.deathList) do
    if i.name == n then return true
    end
  end
  return false
end

onCreatureHealthPercentChange(function(creature, hp)
  if not creature:isPlayer() then return end
  if hp <= 0 then
    local nome = creature:getName()
    local found = false

    for _, i in pairs(st_hud.deathList) do
      if i.name == nome then
        i.time = os.time() + 900
        found = true
        break
      end
    end

    if not found then
      table.insert(st_hud.deathList, {name = nome, time = os.time() + 900})
    end

  end
end)

local function formatTime(time)
  local restante = time - os.time()
  local minutos = math.floor(restante / 60)
  local segundos = restante % 60
  return string.format("%02d:%02d", minutos, segundos)
end


local function renewDeathList()
  deathList.deathList:destroyChildren()
  if not st_hud.deathList then return end
  for _, i in pairs(st_hud.deathList) do
    if i.time > os.time() then
      local l = g_ui.loadUIFromString(playerUI, deathList.deathList)
      l:setText(i.name.. ":     ".. formatTime(i.time))
    else
      table.remove(st_hud.deathList, _)
    end
  end
end

local function reloadScreenThings()
  tUI:setVisible(st_hud.enabled)
  stUI:setVisible(st_hud.enabled)
  deathList:setVisible(st_hud.enabled)
end

reloadScreenThings()
macro(1, function() renewDeathList() end)