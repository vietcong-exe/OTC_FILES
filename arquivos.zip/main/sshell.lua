storage.custom.terminal = storage.custom.terminal or {position={x=0,y=0}, enabled=false}
local termUI = setupUI([[
TerminalLabel < UILabel
  font: terminus-10px
  text-wrap: true
  text-auto-resize: true
  phantom: true

TerminalSelectText < UITextEdit
  font: terminus-10px
  text-wrap: true
  text-align: bottomLeft
  editable: false
  change-cursor-image: false
  cursor-visible: false
  selection-color: black
  selection-background-color: white
  color: alpha
  focusable: false
  auto-scroll: false

UIWindow
  id: termUI
  background-color: #000000
  opacity: 0.85
  visible: false
  clipping: true
  border: 0 white
  $on:
    border: 1 black

  Label
    id:shadow
    anchors.centerIn: parent
    size: 50 50
    opacity: 0.4
    image-source: /bot/Wodahs_1.0/main/gif.png

  Label
    id: titleBar
    font: verdana-11px-rounded
    !text: tr('Shell v1')
    border: 1 black
    color: #d3d3d3
    icon: /bot/Wodahs_1.0/main/icon.png
    anchors.top: parent.top
    anchors.left: parent.left
    anchors.right: parent.right
    background-color: #ffffff11
    text-align: left
    text-offset: 4 0
    height: 18
    visible: false
    font: verdana-11px-rounded
    text-offset: 20 3
    icon-offset: 5 5
    icon-align: left
    icon-size: 10 10

  ScrollablePanel
    id: terminalBuffer
    focusable: false
    anchors.left: parent.left
    anchors.right: terminalScroll.left
    anchors.top: terminalScroll.top
    anchors.bottom: commandTextEdit.top
    layout:
      type: verticalBox
      align-bottom: true
    vertical-scrollbar: terminalScroll
    inverted-scroll: true
    margin-left: 2

  TerminalSelectText
    id: terminalSelectText
    anchors.fill: terminalBuffer
    focusable: false

  VerticalScrollBar
    id: terminalScroll
    anchors.top: parent.top
    anchors.bottom: parent.bottom
    anchors.right: parent.right
    step: 48
    pixels-scroll: true

  UILabel
    id: commandSymbolLabel
    size: 12 12
    fixed-size: true
    anchors.bottom: parent.bottom
    anchors.left: parent.left
    margin-left: 2
    font: terminus-10px
    text: >

  UITextEdit
    id: commandTextEdit
    background: #aaaaaa11
    border-color: #aaaaaa88
    &baseHeight: 12
    anchors.bottom: parent.bottom
    anchors.left: commandSymbolLabel.right
    anchors.right: terminalScroll.left
    margin-left: 1
    padding-left: 2
    font: terminus-10px
    selection-color: black
    selection-background-color: white
    border-width-left: 0
    border-width-top: 0
    multiline: false
    text-auto-submit: true

    $on:
      border-width-left: 1
      border-width-top: 1
      multiline: true

  ResizeBorder
    id: bottomResizeBorder
    anchors.bottom: parent.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    enabled: false

  ResizeBorder
    id: rightResizeBorder
    anchors.right: parent.right
    anchors.top: parent.top
    anchors.bottom: parent.bottom
    enabled: false

]], g_ui.getRootWidget())
termUI:setId("termUI")
termUI:setVisible(storage.custom.terminal.enabled)

importStyle("/main/myscroll.otui")
termUI.terminalScroll:setStyle("MyVerticalScrollBar")
termUI.terminalScroll.incrementButton:setWidth(5)
termUI.terminalScroll.decrementButton:setWidth(5)
termUI.terminalScroll.sliderButton:setWidth(3)
termUI.terminalScroll.sliderButton:setImageSource()
termUI.terminalScroll.sliderButton:setBackgroundColor("#757575")

-- Defina as constantes antes de usar
local LogDebug = 1
local LogInfo = 2
local LogWarning = 3
local LogError = 4

-- Agora você pode criar a tabela sem erro
local LogColors = { 
  [LogDebug] = 'pink',
  [LogInfo] = 'white',
  [LogWarning] = 'yellow',
  [LogError] = 'red' 
}
local MaxLogLines = 128
local MaxHistory = 1000

local _G = modules._G

-- private variables
local commandTextEdit
local terminalBuffer
local commandHistory = { }
local currentHistoryIndex = 0
local poped = false
local oldPos
local oldSize
cachedLines = {}
local disabled = false
local allLines = {}
local logLocked = false
storage.terminalLines = storage.terminalLines or {}


-- private functions


function print(...)
  local msg = ""
  local args = {...}
  local appendSpace = #args > 1
  for i,v in ipairs(args) do
    msg = msg .. tostring(v)
    if appendSpace and i < #args then
      msg = msg .. '    '
    end
  end
  msg = "> ".. msg
  addLine(msg, "green")
end

function warn(...)
  local msg = ""
  local args = {...}
  local appendSpace = #args > 1
  for i,v in ipairs(args) do
    msg = msg .. tostring(v)
    if appendSpace and i < #args then
      msg = msg .. '    '
    end
  end
  msg = "> ".. msg
  return addLine(msg, '#FFFF00')
end

function error(...)
  local msg = ""
  local args = {...}
  local appendSpace = #args > 1
  for i,v in ipairs(args) do
    msg = msg .. tostring(v)
    if appendSpace and i < #args then
      msg = msg .. '    '
    end
  end
  msg = "> ".. msg
  return addLine(msg, '#F55E5E')
end

local function navigateCommand(step)
  if commandTextEdit:isMultiline() then
    return
  end

  local numCommands = #commandHistory
  if numCommands > 0 then
    currentHistoryIndex = math.min(math.max(currentHistoryIndex + step, 0), numCommands)
    if currentHistoryIndex > 0 then
      local command = commandHistory[numCommands - currentHistoryIndex + 1]
      commandTextEdit:setText(command)
      commandTextEdit:setCursorPos(-1)
    else
      commandTextEdit:clearText()
    end
  end
end

local function completeCommand()
  local cursorPos = commandTextEdit:getCursorPos()
  if cursorPos == 0 then return end

  local commandBegin = commandTextEdit:getText():sub(1, cursorPos)
  local possibleCommands = {}

  -- create a list containing all globals
  local allVars = table.copy(_G)

  -- match commands
  for k,v in pairs(allVars) do
    if k:sub(1, cursorPos) == commandBegin then
      table.insert(possibleCommands, k)
    end
  end

  -- complete command with one match
  if #possibleCommands == 1 then
    commandTextEdit:setText(possibleCommands[1])
    commandTextEdit:setCursorPos(-1)
  -- show command matches
  elseif #possibleCommands > 0 then
    terminalPrint('>> ' .. commandBegin)

    -- expand command
    local expandedComplete = commandBegin
    local done = false
    while not done do
      cursorPos = #commandBegin+1
      if #possibleCommands[1] < cursorPos then
        break
      end
      expandedComplete = commandBegin .. possibleCommands[1]:sub(cursorPos, cursorPos)
      for i,v in ipairs(possibleCommands) do
        if v:sub(1, #expandedComplete) ~= expandedComplete then
          done = true
        end
      end
      if not done then
        commandBegin = expandedComplete
      end
    end
    commandTextEdit:setText(commandBegin)
      commandTextEdit:setCursorPos(-1)

    for i,v in ipairs(possibleCommands) do
      print(v)
    end
  end
end

local function doCommand(textWidget)
  local currentCommand = textWidget:getText()
  executeCommand(currentCommand)
  textWidget:clearText()
  return true
end

local function addNewline(textWidget)
  if not textWidget:isOn() then
    textWidget:setOn(true)
  end
  textWidget:appendText('\n')
end

local function onCommandChange(textWidget, newText, oldText)
  local _, newLineCount = string.gsub(newText, '\n', '\n')
  textWidget:setHeight((newLineCount + 1) * textWidget.baseHeight)

  if newLineCount == 0 and textWidget:isOn() then
    textWidget:setOn(false)
  end
end

local function onLog(level, message, time)
  -- if disabled then return end
  -- -- avoid logging while reporting logs (would cause a infinite loop)
  -- if logLocked then return end

  -- logLocked = true
  -- addLine(message, LogColors[level])
  -- logLocked = false
end

function popWindow()
  if poped then
    termUI:fill('parent')
    termUI:getChildById('bottomResizeBorder'):disable()
    termUI:getChildById('rightResizeBorder'):disable()
    termUI:getChildById('titleBar'):hide()
    termUI:getChildById('terminalScroll'):setMarginTop(0)
    termUI:getChildById('terminalScroll'):setMarginBottom(0)
    termUI:getChildById('terminalScroll'):setMarginRight(0)
    poped = false
  else
    termUI:breakAnchors()
    local size = { width = 450, height = 250 }
    termUI:setSize(size)
    termUI:setPosition(storage.custom.terminal.position)
    termUI:getChildById('bottomResizeBorder'):enable()
    termUI:getChildById('rightResizeBorder'):enable()
    termUI:getChildById('titleBar'):show()
    termUI:getChildById('terminalScroll'):setMarginTop(18)
    termUI:getChildById('terminalScroll'):setMarginBottom(1)
    termUI:getChildById('terminalScroll'):setMarginRight(1)
    termUI:bindRectToParent()
    poped = true
  end
end

popWindow()

function toggle()
  if termUI:isVisible() then
    storage.custom.terminal.enabled = false
    hide()
  else
    show()
    storage.custom.terminal.enabled = true
  end
end

function show()
  termUI:show()
  termUI:raise()
  termUI:focus()
  storage.custom.terminal.enabled = true
end

function hide()
  termUI:hide()
  storage.custom.terminal.enabled = false
end

function flushLines()
  local numLines = terminalBuffer:getChildCount() + #cachedLines
  local fulltext = terminalSelectText:getText()

  for _,line in pairs(cachedLines) do
    -- delete old lines if needed
    if numLines > MaxLogLines then
      local firstChild = terminalBuffer:getChildByIndex(1)
      if firstChild then
        local len = #firstChild:getText()
        firstChild:destroy()
        table.remove(allLines, 1)
        fulltext = string.sub(fulltext, len)
      end
    end

    local label = g_ui.createWidget('TerminalLabel', terminalBuffer)
    label:setId('terminalLabel' .. numLines)
    label:setText(line.text)
    label:setColor(line.color)

    table.insert(allLines, {text=line.text,color=line.color})

    fulltext = fulltext .. '\n' .. line.text
  end

  cachedLines = {}
  terminalSelectText:setText(fulltext)
  storage.terminalLines = terminalSelectText:getText()
end

function addLine(text, color)
  schedule(1, flushLines)

  text = string.gsub(text, '\t', '    ')
  table.insert(cachedLines, {text=text, color=color})
end

function terminalPrint(value)
  if type(value) == "table" then
    return print(json.encode(value, 2))
  end
  print(tostring(value))
end

function clear()
  terminalBuffer:destroyChildren()
  terminalSelectText:setText('')
  cachedLines = {}
  allLines = {}
end


commandHistory = g_settings.getList('terminal-history')

commandTextEdit = termUI:getChildById('commandTextEdit')
commandTextEdit:setHeight(commandTextEdit.baseHeight)
g_keyboard.bindKeyPress('Up', function() navigateCommand(1) end, commandTextEdit)
g_keyboard.bindKeyPress('Down', function() navigateCommand(-1) end, commandTextEdit)
g_keyboard.bindKeyPress('Ctrl+C',
  function()
    if commandTextEdit:hasSelection() or not terminalSelectText:hasSelection() then return false end
    g_window.setClipboardText(terminalSelectText:getSelection())
  return true
  end, commandTextEdit)
g_keyboard.bindKeyDown('Tab', completeCommand, commandTextEdit)
g_keyboard.bindKeyPress('Shift+Enter', addNewline, commandTextEdit)
g_keyboard.bindKeyDown('Enter', doCommand, commandTextEdit)
g_keyboard.bindKeyDown('Escape', hide, termUI)

terminalBuffer = termUI:getChildById('terminalBuffer')
terminalSelectText = termUI:getChildById('terminalSelectText')
terminalSelectText.onDoubleClick = popWindow
terminalSelectText.onMouseWheel = function(a,b,c) terminalBuffer:onMouseWheel(b,c) end
terminalBuffer.onScrollChange = function(self, value) terminalSelectText:setTextVirtualOffset(value) end

local function clearTerminal()
  clear()
  terminalPrint("shell cleaned.")
end

function executeCommand(command)
  if command == nil or #string.gsub(command, '\n', '') == 0 then return end

  -- add command line
  addLine("> " .. command, "#ffffff")

  -- reset current history index
  currentHistoryIndex = 0

  -- add new command to history
  if #commandHistory == 0 or commandHistory[#commandHistory] ~= command then
    table.insert(commandHistory, command)
    while #commandHistory > MaxHistory do
      table.remove(commandHistory, 1)
    end
  end

  -- detect and convert commands with simple syntax
  local realCommand
  if string.sub(command, 1, 1) == '=' then
    realCommand = "terminalPrint(".. string.sub(command,2).. ")"
  elseif (command == "cls") or (command == "clear") then
    realCommand = clearTerminal
  else
    realCommand = command
  end

  local func, err = loadstring(realCommand, "@")

  -- check for syntax errors
  if not func then
    addLine('ERROR: incorrect lua syntax: ' .. err:sub(5), 'red')
    return
  end
  

  -- execute the command
  local ok, ret = pcall(func)
  if ok then
    -- if the command returned a value, print it
    if ret then addLine(ret, 'white') end
  else
    addLine('ERROR: command failed: ' .. ret, 'red')
  end
end


g_keyboard.bindKeyDown('Ctrl+X', toggle)
termUI.onDoubleClick = popWindow

local function miscMovable()
  termUI.onDragEnter = function(widget, mousePos)
    widget:breakAnchors()
    widget.movingReference = { x = mousePos.x - widget:getX(), y = mousePos.y - widget:getY() }
    return true
  end
  
  termUI.onDragMove = function(widget, mousePos, moved)
    local parentRect = widget:getParent():getRect()
    local x = math.min(math.max(parentRect.x, mousePos.x - widget.movingReference.x), parentRect.x + parentRect.width - widget:getWidth())
    local y = math.min(math.max(parentRect.y - widget:getParent():getMarginTop(), mousePos.y - widget.movingReference.y), parentRect.y + parentRect.height - widget:getHeight())        
    widget:move(x, y)

    return true
  end
  
  termUI.onDragLeave = function(widget, pos)
    storage.custom.terminal.position.x = widget:getX();
    storage.custom.terminal.position.y = widget:getY();
    return true
  end
end

miscMovable()
function terminalHistory()
  if #storage.terminalLines == 0 then return end
  for _, text in pairs(storage.terminalLines:split("\n")) do
    if not text:find("shell") then
      addLine(text, "gray")
    end
  end
end

terminalHistory()


storage.custom.moveTerminal = storage.custom.moveTerminal or {enabled = true}

if storage.custom.moveTerminal.enabled then
  termUI:setPosition({x=500, y=500})
  storage.custom.moveTerminal.enabled = false
end