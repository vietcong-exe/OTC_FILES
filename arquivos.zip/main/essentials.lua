storage.custom.esWindow = storage.custom.esWindow or {type = "min", enabled = false, position = {x=0,y=0}}
local esMini = setupUI([[
MiniWindow
  font: verdana-11px-rounded
  id: misc
  !text: tr('Essentials')
  icon: /bot/Wodahs_1.0/main/icon.png
  icon-size: 10 10
  icon-offset: 3 3
  @onClose: modules.game_bot.onMiniWindowClose()
  &save: true
  &autoOpen: 10
  image-source:
  opacity: 0.8
  background-color: black
  visible: false

  MiniWindowContents
    layout:
      type: verticalBox



]], modules.game_interface.getLeftPanel())
esMini:setId("esMini")

esMini:setVisible(storage.custom.esWindow.enabled or false)
if storage.custom.esWindow.type == "min" then
  esMini:minimize()
else
  esMini:maximize()
end

--miscMini:minimize()
esMini:setPosition({x=storage.custom.esWindow.position.x,y=storage.custom.esWindow.position.y} or {x=0,y=0})

esMini.closeButton:setImageColor("red")
esMini.minimizeButton:setImageColor("#00FFFF")
esMini.lockButton:setImageColor("yellow")

esMini.minimizeButton.onClick = function(self)
  if self:isOn() then
    esMini:maximize()
    storage.custom.esWindow.type = "max"
  else
    esMini:minimize()
    storage.custom.esWindow.type = "min"
  end

end

esMini.lockButton.onClick = function(self)
  if esMini:isDraggable() then
    esMini:lock()
  else
    esMini:unlock()
  end
end

esMini.closeButton.onClick = function(self)
  storage.custom.esWindow.enabled = not storage.custom.esWindow.enabled

  esMini:hide()
end

importStyle("/main/myscroll.otui")
esMini.miniwindowScrollBar:setStyle("MyVerticalScrollBar")
esMini.miniwindowScrollBar.incrementButton:setWidth(5)
esMini.miniwindowScrollBar.decrementButton:setWidth(5)
esMini.miniwindowScrollBar.sliderButton:setWidth(3)
esMini.miniwindowScrollBar.sliderButton:setImageSource()
esMini.miniwindowScrollBar.sliderButton:setBackgroundColor("#757575")
local function miscMovable()
  esMini.onDragEnter = function(widget, mousePos)
    widget:breakAnchors()
    widget:setParent(g_ui.getRootWidget())
    widget.movingReference = { x = mousePos.x - widget:getX(), y = mousePos.y - widget:getY() }
    return true
  end
  
  esMini.onDragMove = function(widget, mousePos, moved)
    local parentRect = widget:getParent():getRect()
    local x = math.min(math.max(parentRect.x, mousePos.x - widget.movingReference.x), parentRect.x + parentRect.width - widget:getWidth())
    local y = math.min(math.max(parentRect.y - widget:getParent():getMarginTop(), mousePos.y - widget.movingReference.y), parentRect.y + parentRect.height - widget:getHeight())        
    widget:move(x, y)
    widget:setBorderWidth(1)
    widget:setBorderColor("teal")
    return true
  end
  
  esMini.onDragLeave = function(widget, pos)
    storage.custom.esWindow.position.x = widget:getX();
    storage.custom.esWindow.position.y = widget:getY();

    widget:setBorderWidth(0)
    return true
  end
end

miscMovable()



lblInfo= UI.Label("------- COMBO -------", esMini.contentsPanel)
lblInfo:setColor("#f8f8ff")
lblInfo:setFont("verdana-11px-rounded")

local cmbui = setupUI([[
Panel
  height: 50

  BotSwitch
    id: title
    anchors.top: parent.top
    anchors.left: parent.left
    text-align: center
    width: 130
    height: 17
    !text: tr('Combo')

  Button
    id: Add
    anchors.top: prev.top
    anchors.left: prev.right
    margin-left: 3
    height: 17
    width: 25
    text: +
    tooltip: Add Spell

  Button
    id: Remove
    anchors.top: prev.top
    anchors.left: prev.right
    anchors.right: parent.right
    margin-left: 3
    height: 17
    text: -
    tooltip: Remove Spell

  ScrollablePanel
    anchors.left: title.left
    anchors.right: Remove.right
    anchors.top: prev.bottom
    margin-top: 5
    height: 20
    id: Panel
    anchors.bottom: parent.bottom
    layout:
      type: verticalBox    
      
]], esMini.contentsPanel)

storage.custom.esWindow.combo = storage.custom.esWindow.combo or {index=1, spells = {}, enabled = false}
cmbui.title:setOn(storage.custom.esWindow.combo.enabled)

cmbui.title.onClick = function(self)
  storage.custom.esWindow.combo.enabled = not storage.custom.esWindow.combo.enabled
  self:setOn(storage.custom.esWindow.combo.enabled)
end


local function reloadSpells()
  cmbui.Panel:destroyChildren()

  for i=1,storage.custom.esWindow.combo.index do
    local teste = addTextEdit("cmbTE"..i, storage.custom.esWindow.combo.spells[i] or "", function(self, text)
      storage.custom.esWindow.combo.spells[i]  = text
   end, cmbui.Panel)
   cmbui:setHeight(20 + 20*i)
   teste:setPlaceholder(i)
  end
end

reloadSpells()

cmbui.Add.onClick = function(self)
  storage.custom.esWindow.combo.index = storage.custom.esWindow.combo.index + 1
  print(storage.custom.esWindow.combo.index)
  reloadSpells()
end

cmbui.Remove.onClick = function(self)
  if storage.custom.esWindow.combo.index <= 1 then return end
  storage.custom.esWindow.combo.index = storage.custom.esWindow.combo.index - 1
  reloadSpells()
end

macro(1, function()
  if not storage.custom.esWindow.combo.enabled then return end
  if not g_game.getAttackingCreature() then return end
  for index, spell in pairs(storage.custom.esWindow.combo.spells) do
    say(spell)
  end
end)


lblInfo= UI.Label("-------- HEAL --------", esMini.contentsPanel)
lblInfo:setColor("#f8f8ff")
lblInfo:setFont("verdana-11px-rounded")
Panels.Health (esMini.contentsPanel)

lblInfo= UI.Label("-------- FUGA --------", esMini.contentsPanel)
lblInfo:setColor("#f8f8ff")
lblInfo:setFont("verdana-11px-rounded")

if type(storage.healing3) ~= "table" then
  storage.healing3 = {on=false, title="HP%", text="fuga", min=0, max=80}
end
if type(storage.healing4) ~= "table" then
  storage.healing4 = {on=false, title="HP%", text="fuga", min=0, max=70}
end
if type(storage.healing5) ~= "table" then
  storage.healing5 = {on=false, title="HP%", text="fuga", min=0, max=50}
end
if type(storage.healing6) ~= "table" then
  storage.healing6 = {on=false, title="HP%", text="fuga", min=0, max=30}
end

-- create 2 healing widgets
for _, healingInfo in ipairs({storage.healing3, storage.healing4, storage.healing5, storage.healing6}) do
  local healingmacro = macro(20, function()
    local hp = player:getHealthPercent()
    if healingInfo.max >= hp and hp >= healingInfo.min then
        say(healingInfo.text)
    end
  end)
  healingmacro.setOn(healingInfo.on)

  UI.DualScrollPanel(healingInfo, function(widget, newParams) 
    healingInfo = newParams
    healingmacro.setOn(healingInfo.on)
  end, esMini.contentsPanel)
end

lblInfo= UI.Label("-------- POTS --------", esMini.contentsPanel)
lblInfo:setColor("#f8f8ff")
lblInfo:setFont("verdana-11px-rounded")
Panels.HealthItem(esMini.contentsPanel)
Panels.HealthItem(esMini.contentsPanel)
Panels.ManaItem(esMini.contentsPanel)



lblInfo= UI.Label("-------- FOOD --------", esMini.contentsPanel)
lblInfo:setColor("#f8f8ff")
lblInfo:setFont("verdana-11px-rounded")
if type(storage.foodItems) ~= "table" then
  storage.foodItems = {3582, 3577}
end

local foodContainer = UI.Container(function(widget, items)
  storage.foodItems = items
end, true, esMini.contentsPanel)
foodContainer:setHeight(35)
foodContainer:setItems(storage.foodItems)

UI.Label("------ MANASHIELD ------", esMini.contentsPanel)
UI.TextEdit(storage.manaShield or "utamo vita", function(widget, newText)
  storage.manaShield = newText
end, esMini.contentsPanel)

local lastManaShield = 0
macro(20, "mana shield", function() 
  if hasManaShield() or lastManaShield + 90000 > now then return end
  if TargetBot then 
    TargetBot.saySpell(storage.manaShield) -- sync spell with targetbot if available
  else
    say(storage.manaShield)
  end
end, esMini.contentsPanel)

UI.Label("------- HASTE --------", esMini.contentsPanel)
UI.TextEdit(storage.hasteSpell or "concentrate chakra feet", function(widget, newText)
  storage.hasteSpell = newText
end, esMini.contentsPanel)

macro(500, "haste", function() 
  if hasHaste() then return end
  if TargetBot then 
    TargetBot.saySpell(storage.hasteSpell) -- sync spell with targetbot if available
  else
    say(storage.hasteSpell)
  end
end, esMini.contentsPanel)

UI.Label("--- ANTYPARA ---", esMini.contentsPanel)
UI.TextEdit(storage.antiParalyze or "concentrate chakra feet", function(widget, newText)
  storage.antiParalyze = newText
end, esMini.contentsPanel)

macro(100, "anti paralyze", function() 
  if not isParalyzed() then return end
  if TargetBot then 
    TargetBot.saySpell(storage.antiParalyze) -- sync spell with targetbot if available
  else
    say(storage.antiParalyze)
  end
end, esMini.contentsPanel)


macro(10000, "Eat Food", function()
  if player:getRegenerationTime() > 400 or not storage.foodItems[1] then return end
  -- search for food in containers
  for _, container in pairs(g_game.getContainers()) do
    for __, item in ipairs(container:getItems()) do
      for i, foodItem in ipairs(storage.foodItems) do
        if item:getId() == foodItem.id then
          return g_game.use(item)
        end
      end
    end
  end
end, esMini.contentsPanel)

lblInfo= UI.Label("-------- BUFF --------", esMini.contentsPanel)
lblInfo:setColor("#f8f8ff")
lblInfo:setFont("verdana-11px-rounded")


buffz = macro(1000, "Buff", function()
if not hasPartyBuff() then
 say(storage.buff)
schedule(1300, function() say(storage.buff2) end)
end
end, esMini.contentsPanel)



addTextEdit("buff", storage.buff or "buff", function(widget, text) storage.buff = text
end, esMini.contentsPanel)

        color= UI.Label("--------- BUFF 2 ---------", esMini.contentsPanel)
color:setColor("#f8f8ff")


addTextEdit("buff2", storage.buff2 or "buff 2", function(widget, text) storage.buff2 = text
end, esMini.contentsPanel)
 




lblInfo= UI.Label("------- TREINO -------", esMini.contentsPanel)
lblInfo:setColor("#f8f8ff")
lblInfo:setFont("verdana-11px-rounded")
if type(storage.manatrainer) ~= "table" then
  storage.manatrainer = {on=false, title="mana%", text="Power Down", min=0, max=90}
end

for _, healingInfos in ipairs({storage.manatrainer}) do
  local healingmacro = macro(20, function()
    local mana = manapercent()
    if healingInfos.max <= mana and mana >= healingInfos.min then
        say(healingInfos.text)
      end
  end)
  healingmacro.setOn(healingInfos.on)

  UI.DualScrollPanel(healingInfos, function(widget, newParams) 
    healingInfos = newParams
    healingmacro.setOn(healingInfos.on)
  end, esMini.contentsPanel)
end 
healingmacro = macro(20, "Dance", function()
    turn(math.random(0, 3))
end, esMini.contentsPanel)

setDefaultTab("Main")
local essButton = UI.Button("Essentials", function() esMini:setVisible(not esMini:isVisible()); esMini:minimize(); storage.custom.esWindow.enabled = not storage.custom.esWindow.enabled; end)
essButton:setFont("verdana-11px-rounded")