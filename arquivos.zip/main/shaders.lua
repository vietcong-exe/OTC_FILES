local _G = modules._G
local cfg = modules.game_bot.contentsPanel.config:getCurrentOption().text
local path = "/bot/".. cfg .. "/main/shaders/"
_G.g_shaders.createOutfitShader("ShaderLightBlue", path.."outline_vertex", path.. "outline_light_blue_fragment")
_G.g_shaders.createOutfitShader("ShaderBlue", path.. "outline_vertex", path.. "outline_blue_fragment")
_G.g_shaders.createOutfitShader("ShaderRed", path.. "outline_vertex", path.. "outline_red_fragment")
_G.g_shaders.createOutfitShader("ShaderPurple", path.. "outline_vertex", path.. "outline_purple_fragment")
_G.g_shaders.createOutfitShader("ShaderWhite", path.. "outline_vertex", path.. "outline_white_fragment")
_G.g_shaders.createOutfitShader("ShaderLightBlueStatic", path.. "outline_vertex", path.. "outline_light_blue_static_fragment")
_G.g_shaders.createOutfitShader("ShaderBlueStatic", path.. "outline_vertex", path.. "outline_blue_static_fragment")
_G.g_shaders.createOutfitShader("ShaderRedStatic", path.. "outline_vertex", path.. "outline_red_static_fragment")
_G.g_shaders.createOutfitShader("ShaderPurpleStatic", path.. "outline_vertex", path.. "outline_purple_static_fragment")
_G.g_shaders.createOutfitShader("ShaderWhiteStatic", path.. "outline_vertex", path.. "outline_white_static_fragment")
_G.g_shaders.createOutfitShader("ShaderGreen", path.. "outline_vertex", path.. "outline_green_fragment")
_G.g_shaders.createOutfitShader("ShaderGreenStatic", path.. "outline_vertex", path.. "outline_green_static_fragment")
_G.g_shaders.createOutfitShader("ShaderYellow", path.. "outline_vertex", path.. "outline_yellow_fragment")
_G.g_shaders.createOutfitShader("ShaderYellowStatic", path.. "outline_vertex", path.. "outline_yellow_static_fragment")