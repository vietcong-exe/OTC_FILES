panel = mainTab;

excludeIds = excludeIds or {
    12099,
    17393
};

stairsIds = stairsIds or {
    1666,
    6207,
    1948,
    435,
    7771,
    5542,
    8657,
    6264,
    1646,
    1648,
    1678,
    5291,
    1680,
    6905,
    6262,
    1664,
    13296,
    1067,
    13861,
    11931,
    1949,
    6896,
    6205,
    13926,
    1947,
    12097,
	615,
	1678, -- DOOR
	8367, -- DOOR
};

-- updateIds = function()
-- 	excludeIds = {};
-- 	stairsIds = {};
	
	
-- 	for _, value in ipairs(storage.stairsIds) do
-- 		stairsIds[value.id] = true;
-- 	end
	
-- 	for _, value in ipairs(storage.excludeIds) do
-- 		excludeIds[value.id] = true;
-- 	end
	
-- 	-- info(json.encode(storage.stairsIds));
-- end

setDefaultTab("Main")
-- if (not stairsIdContainer) then
-- 	UI.Label('Escadas & Portas')
	
-- 	local stairsCallback = function(widget, items)
-- 		storage.stairsIds = items;
-- 		updateIds();
-- 	end
	
-- 	stairsIdContainer = UI.Container(stairsCallback, true);


-- 	storage.stairsIds = storage.stairsIds or stairsIds;
-- 	stairsIdContainer:setItems(storage.stairsIds);
-- 	stairsIdContainer:setHeight(35);
-- 	UI.Separator();
-- end

-- if (not excludeIdsContainer) then
-- 	UI.Label('Ids exclu�dos');
	
-- 	local excludeCallback = function(widget, items)
-- 		storage.excludeIds = items;
-- 		updateIds();
-- 	end
	
-- 	excludeIdsContainer = UI.Container(excludeCallback, true);
	
	
-- 	storage.excludeIds = storage.excludeIds or excludeIds;
-- 	excludeIdsContainer:setItems(storage.excludeIds);
-- 	excludeIdsContainer:setHeight(35);
-- 	UI.Separator();
-- end

--updateIds();

local isMobile = modules._G.g_app.isMobile();

local bugMap = {};

TILE_METHODS = modules._G.Tile_mt.methods;

TILE_METHODS.clearText = function(self, delay)
	delay = delay or 0;
	local clearTime = now + delay;
	self.clearTime = clearTime;
    schedule(delay, function()
		if (self.clearTime ~= clearTime) then return; end
		self:setText("");
	end)
end

TILE_METHODS.isStair = function(self, ignoreCreatures)
    local tilePos = self:getPosition();
    if (not tilePos) then return; end
	
	if (not self:isWalkable(ignoreCreatures)) then return; end
	
	local tileItems = self:getItems();
	local topId;

    for _, item in ipairs(tileItems) do
		local itemId = item:getId();
        if (excludeIds[itemId]) then return; end
		topId = itemId;
    end

    if (stairsIds[itemId]) then return true; end
	
	local topUseThing = self:getTopUseThing();
	
	if (topUseThing and stairsIds[topUseThing:getId()]) then return true; end

    local color = g_map.getMinimapColor(tilePos);
	return color >= 210 and color <= 213 and not self:isPathable();	
end



bugMap.correctDirection = function()
	local dir = player:getDirection();
	return dir <= 3 and dir or dir < 6 and 1 or 3;
end


bugMap.positions = {
	[0] = {x = 0, y = -5},
	[1] = {x = 5, y = 0},
	[2] = {x = 0, y = 5},
	[3] = {x = -5, y = 0}
}

bugMap.getIteration = function(dir)
	local base = bugMap.positions[dir];
	
	local val = {};
	
	local x, y = base.x, base.y;
	val.x = {startIter = x < 0 and x or 0, endIter = x > 0 and x or 0};
	val.y =	{startIter = y < 0 and y or 0, endIter = y > 0 and y or 0};
	
	
	return val.x, val.y;
end
	
bugMap.getDistance = function(p1, p2)

    local distx = math.abs(p1.x - p2.x);
    local disty = math.abs(p1.y - p2.y);

    return math.sqrt(distx * distx + disty * disty);
end

function bugMap:forceWalking()
	local walkPos = self.walkingPos;
	
	local tile = g_map.getTile(walkPos);
	if (not tile) then return; end
	
	local topThing = tile:getTopThing();
	if (not topThing) then return; end
	
	local playerPos = player:getPosition();
	if (playerPos.z ~= walkPos.z) then return; end
	
	local path = findPath(playerPos, walkPos);
	if (not path) then return; end
	
	tile:setText("Here!", "green");
	tile:clearText(200);

	if (player:isAutoWalking()) then
		player:stopAutoWalk();
		g_game.stop();
	end
	
	player:lockWalk(150);
	
	g_game.use(topThing);
	return not autoWalk(walkPos, 1);
end

bugMap.verifyTiles = function(dir)
	if (bugMap.correctDirection() ~= dir) then
		g_game.turn(dir);
	end
	local x, y = bugMap.getIteration(dir);
	
	local nearest = {};
	local pos = pos();
	local playerTile = player:getTile();
	for x = x.startIter, x.endIter do
		for y = y.startIter, y.endIter do
			local newPos = {x = pos.x + x, y = pos.y + y, z = pos.z};
			local tile = g_map.getTile(newPos);
			if (tile and tile ~= playerTile) then
				local distance = bugMap.getDistance(newPos, pos);
				if (not nearest.distance or nearest.distance < distance) then
					if (tile:isStair()) then
						nearest.pos = newPos;
						nearest.distance = distance;
					end
				end
			end
		end
	end
	
	if (nearest.pos) then
		bugMap.walkingPos = nearest.pos;
		return true;
	end
end

bugMap.handleUse = function(x, y, dir)

	if (x == 0 or y == 0) then
		if (bugMap.verifyTiles(dir)) then return; end
	elseif (x ~= 0 and y ~= 0) then
		x = x > 0 and 3 or -3;
		y = y > 0 and 3 or -3;
	end

	local pos = pos();
	pos.x = pos.x + x;
	pos.y = pos.y + y;

	
	local tile = g_map.getTile(pos);
	if (not tile) then return; end
	
	local topThing = tile:getTopThing();
	if (not topThing) then return; end
	if (storage.useKunai and storage.kunaiId and storage.bugMapKunai and tile:isWalkable(true)) then
		useWith(storage.kunaiId, topThing);
	end
	-- player:lockWalk(50)	
	g_game.use(topThing);
end


bugMap.basis = {
	["W"] = {
		dir = 0,
		sum = {x = 0, y = -5}
	},

	["A"] = {
		dir = 3,
		sum = {x = -5, y = 0}
	},

	["S"] = {
		dir = 2,
		sum = {x = 0, y = 5}
	},

	["D"] = {
		dir = 1,
		sum = {x = 5, y = 0}
	}
};



local keyXarrow = {
	["W"] = "Up",
	["A"] = "Left",
	["S"] = "Down",
	["D"] = "Right"
};


for key, arrow in pairs(keyXarrow) do
	bugMap.basis[arrow] = table.copy(bugMap.basis[key]);
	bugMap.basis[key].wasdWalking = true;
end

if (isMobile) then
	local keypad = g_ui.getRootWidget():recursiveGetChildById("keypad");
	bugMap.pointer = keypad.pointer;

	local North = {
		highest = {x = -16, y = 29},
		lowest = {x = -75, y = -30},
		info = {
			dir = 0,
			sum = {x = 0, y = -5}
		};
	};
	local East = {
		highest = {x = 29, y = 75},
		lowest = {x = -30, y = 15},
		info = {
			dir = 1,
			sum = {x = 5, y = 0}
		};
	};
	local South = {
		highest = {x = 75, y = 29},
		lowest = {x = 16, y = -30},
		info = {
			dir = 2,
			sum = {x = 0, y = 5}
		};
	};
	local West = {
		highest = {x = 29, y = -15},
		lowest = {x = -30, y = -75},
		info = {
			dir = 3,
			sum = {x = -5, y = 0}
		};
	};
	local SouthWest = {
		highest = {x = 69, y = -28},
		lowest = {x = 28, y = -69},
		info = {
			sum = {x = -3, y = 3}
		};
	};
	local NorthWest = {
		highest = {x = -28, y = -29},
		lowest = {x = -69, y = -69},
		info = {
			sum = {x = -3, y = -3}
		};
	};
	local SouthEast = {
		highest = {x = 70, y = 70},
		lowest = {x = 30, y = 30},
		info = {
			sum = {x = 3, y = 3}
		};
	};
	local NorthEast = {
		highest = {x = -29, y = 68},
		lowest = {x = -69, y = 29},
		info = {
			sum = {x = 3, y = -3}
		};
	};
	DIRS = {North, East, South, West, NorthEast, SouthEast, SouthWest, NorthWest};
end

bugMap.getPressedKeys = function()
	local pressedKeys = {};
	local wasdWalking = modules.game_walking.wsadWalking;
	
	if (isMobile) then
		local marginTop, marginLeft = bugMap.pointer:getMarginTop(), bugMap.pointer:getMarginLeft();
		for index, value in ipairs(DIRS) do
			if (
				(marginTop >= value.lowest.x and marginTop <= value.highest.x) and
				(marginLeft >= value.lowest.y and marginLeft <= value.highest.y)
			) then
				table.insert(pressedKeys, value.info);
			end
		end
	else
		for walkKey, value in pairs(bugMap.basis) do
			if (modules.corelib.g_keyboard.isKeyPressed(walkKey)) then
				-- local tbl = pressedKeys[value.wasdWalking and 'wordKey' or 'arrowKey'];
				if (not value.wasdWalking or wasdWalking) then
					table.insert(pressedKeys, value);
				end
			end
		end
	end
	return pressedKeys;
end

local rootPanel = g_ui.getRootWidget():recursiveGetChildById('gameRootPanel');

setDefaultTab("Main")
macro(1, "Bug-Map", function()
	if (not rootPanel:isFocused()) then return; end
	if (g_keyboard.isCtrlPressed()) then return; end
	if (bugMap.walkingPos) then
		if (bugMap:forceWalking()) then return; else bugMap.walkingPos = nil; end
		return;
	end
 	
	local pressedKeys = bugMap.getPressedKeys();
	
	if (#pressedKeys == 0) then return; end
	
	local sumPos = {x = 0, y = 0};
	
	for index, value in ipairs(pressedKeys) do
		local val = value.sum;
		if ((sumPos.x ~= 0 and val.x ~= 0) or (sumPos.y ~= 0 and val.y ~= 0)) then
			goto continue;
		end
		sumPos.x = sumPos.x + val.x;
		sumPos.y = sumPos.y + val.y;
		::continue::
	end
	
	bugMap.handleUse(sumPos.x, sumPos.y, pressedKeys[1].dir);	
end)