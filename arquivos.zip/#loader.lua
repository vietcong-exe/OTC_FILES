cfg = modules.game_bot.contentsPanel.config:getCurrentOption().text
images = "/bot/".. cfg .."/main/" 
-- styles loader 
storage.custom = storage.custom or {}

local configFiles = g_resources.listDirectoryFiles("/bot/" .. cfg .. "/main", true, false)
for i, file in ipairs(configFiles) do
  local ext = file:split(".")
  if ext[#ext]:lower() == "ui" or ext[#ext]:lower() == "otui" then
    g_ui.importStyle(file)
  end
end

local function loadMainScript(name)
  return dofile("/main/" .. name .. ".lua")
end

local function loadScripts(name)
  return dofile("/scripts/" .. name .. ".lua")
end

local luaMainFiles = {
  "shaders";
  "vlib";
  "beauty";
  "new_cavebot_lib";
  "cavebot";
  "sshell";
  "hud";
  "shEditor";
  "misc";
  "essentials";
  "Cosmetics";
  "bugmap";
  "combo";
  "keep";
  "Bestiary";
}



for i, file in ipairs(luaMainFiles) do
  loadMainScript(file)
end