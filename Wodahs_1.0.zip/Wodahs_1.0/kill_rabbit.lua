storage.custom.kill_rabbit = storage.custom.kill_rabbit or {distance = 10, enabled = false, friendly = true, spells = {}}

local ui = setupUI([[
Panel
  height: 18

  BotSwitch
    text: KILL_RABBIT
    anchors.left: parent.left
    anchors.top: parent.top
    font: verdana-11px-rounded
    width: 120
    id: title

  BotButton
    id: edit
    text: Edit
    anchors.left: prev.right
    anchors.top: parent.top
    anchors.right: parent.right
]])

ui.title.onClick = function(self)
  storage.custom.kill_rabbit.enabled = not storage.custom.kill_rabbit.enabled
  self:setOn(storage.custom.kill_rabbit.enabled)
end
ui.title:setOn(storage.custom.kill_rabbit.enabled)

local window = setupUI([[

CloseButton < UIButton
  id: closeButton
  anchors.top: parent.top
  anchors.right: parent.right
  image-color:red
  margin-top: 5
  margin-right: 10
  size: 14 14
  image-source: /images/ui/miniwindow_buttons
  image-clip: 28 0 14 14

  $hover:
    image-clip: 28 14 14 14

  $pressed:
    image-clip: 28 28 14 14

DistanceLabel < Label
  anchors.left: prev.right
  margin-left: 4
  anchors.top: prev.top
  margin-top: 2
  size: 11 15
  border: 1 white
  phantom: false

MainWindow
  size: 550 250
  image-source:
  padding: 0
  border: 2 black
  visible: false

  Label
    id: background
    anchors.fill: parent
    opacity: 0.5
    background-color: black
  Label
    id: icon
    anchors.centerIn: parent
    size: 200 200
    opacity: 0.3
    margin: 5
    image-source: /bot/Wodahs_1.0/main/kill_rabbit.png

  CloseButton
    @onClick: self:getParent():hide()

  Label
    id: background
    anchors.fill: spellPanel
    background-color: black
    opacity: 0.5

  ScrollablePanel
    id: spellPanel
    anchors.verticalCenter: parent.verticalCenter
    size: 300 200
    border: 2 black
    anchors.left: parent.left
    margin-left: 10
    layout:
      type: verticalBox
      auto-spacing: 
    vertical-scrollbar: scrollBar

  Panel
    id: things
    anchors.left: prev.right
    anchors.right: parent.right
    anchors.top:prev.top
    anchors.bottom: prev.bottom
    border: 2 black
    margin-left: 10
    margin-right: 10
    Label
      id: background
      anchors.fill: parent
      background-color: black
      opacity: 0.5

    TextEdit
      id: spell
      anchors.left: parent.left
      anchors.right: parent.right
      anchors.top: parent.top
      margin: 5
      image-source:
      color: white
      background-color: black
      border: 1 gray
      placeholder: > insert spell here
      placeholder-font: verdana-9px

    TextEdit
      id: cooldown
      anchors.left: parent.left
      anchors.right: parent.right
      anchors.top: prev.bottom
      margin: 5
      image-source:
      color: white
      background-color: black
      border: 1 gray
      placeholder: > insert cooldown here (ms)
      placeholder-font: verdana-9px

    Label
      text: DISTANCE:
      text-auto-resize: true
      anchors.left: parent.left
      anchors.top: prev.bottom
      margin-left: 5
      margin-top: 5
      font: terminus-14px-bold

    DistanceLabel
      id: distance1
      margin-left: 3
    DistanceLabel
      id: distance2
      margin-top:
    DistanceLabel
      id: distance3
      margin-top:
    DistanceLabel
      id: distance4
      margin-top:
    DistanceLabel
      id: distance5
      margin-top:
    DistanceLabel
      id: distance6
      margin-top:
    DistanceLabel
      id: distance7
      margin-top:
    DistanceLabel
      id: distance8
      margin-top:
    DistanceLabel
      id: distance9
      margin-top:
    DistanceLabel
      id: distance10
      margin-top:

    CheckBox
      id: friend
      text-auto-resize: true
      text: Friendly Safe
      anchors.left: parent.left
      margin-left: 5
      anchors.top: prev.bottom
      margin-top: 20
      font: verdana-11px-rounded
      tooltip: Don't attack party members, guild members...

    BotButton
      id: add
      text: ADD SPELL
      font: verdana-11px-rounded
      anchors.left: parent.left
      anchors.right: parent.right
      anchors.bottom: parent.bottom
      margin: 3
  VerticalScrollBar
    id: scrollBar
    anchors.right: spellPanel.right
    anchors.top: spellPanel.top
    anchors.bottom: spellPanel.bottom

]], g_ui.getRootWidget())


ui.edit.onClick = function(self)
  if window:isVisible() then
    window:hide()
  else
    window:show()
    window:focus()
    window:raise()
  end
end

window.things.friend.onClick = function(self)
  storage.custom.kill_rabbit.friendly = not storage.custom.kill_rabbit.friendly
  self:setChecked(storage.custom.kill_rabbit.friendly)
end
window.things.friend:setChecked(storage.custom.kill_rabbit.friendly)

window.scrollBar:setStyle("MyVerticalScrollBar")
window.scrollBar.incrementButton:setWidth(5)
window.scrollBar.decrementButton:setWidth(5)
window.scrollBar.sliderButton:setWidth(3)
window.scrollBar.sliderButton:setImageSource()
window.scrollBar.sliderButton:setBackgroundColor("#757575")
local spellEntry = [[
UIWidget
  height: 20
  padding:2
  background-color: alpha
  $hover:
    background-color: black
  $focus:
    background-color: black
  
  BotSwitch
    id: enabled
    size: 15 15
    anchors.left: parent.left
    margin-left: 5
    anchors.verticalCenter: parent.verticalCenter
    tooltip: Enable/Disable
  Label
    id: text
    anchors.left: prev.right
    margin-left: 5
    anchors.right: moveUp.left
    margin-right: 5
    text-align: center
    anchors.verticalCenter: parent.verticalCenter
    font: verdana-11px-rounded
  BotButton
    id: moveUp
    text: ^
    size: 15 15
    tooltip: MoveUp
    anchors.right: moveDown.left
    margin-right: 2
    anchors.verticalCenter: parent.verticalCenter
  BotButton
    id: moveDown
    text: ^
    rotation: 180
    size: 15 15
    tooltip: MoveDown
    anchors.right: remove.left
    anchors.verticalCenter: parent.verticalCenter
    
  BotButton
    id: remove
    tooltip: Remove
    text: x
    size: 15 15
    anchors.right: parent.right
    anchors.verticalCenter: parent.verticalCenter
    margin-right: 5
    
]]
local function colorizeDistance()
  for _, child in pairs(window.things:getChildren()) do
    if child:getStyleName() == "DistanceLabel" then
      child:setBackgroundColor("alpha")
      if tonumber(child:getId():split("ce")[2]) <= storage.custom.kill_rabbit.distance then
        child:setBackgroundColor("green")
      end
    end
  end
end
colorizeDistance()

for _, c in pairs(window.things:getChildren()) do
  if c:getStyleName() == "DistanceLabel" then
    c.onClick = function(self)
      local number = tonumber(self:getId():split("ce")[2])
      storage.custom.kill_rabbit.distance = number
      colorizeDistance()
    end
  end
end

local function reloadSpellPanel()
  window.spellPanel:destroyChildren()
  for _, value in pairs(storage.custom.kill_rabbit.spells) do
    local s = g_ui.loadUIFromString(spellEntry, window.spellPanel)
    s.text:setText(value.spell)
    s.enabled:setOn(value.enabled)
    local cooldown = tostring(value.cd)
    local distance = value.dist
    s:setTooltip("Cooldown: ".. cooldown.. "\nDistance: ".. distance)
    s.remove.onClick = function(self)
      table.removevalue(storage.custom.kill_rabbit.spells, value)
      s:destroy()
    end
    s.moveUp.onClick = function(self)
      local input = self:getParent()
      local index = window.spellPanel:getChildIndex(input)
      if index < 2 then return end
      local t = storage.custom.kill_rabbit.spells
      t[index],t[index-1] = t[index-1], t[index]
      window.spellPanel:moveChildToIndex(input, index - 1)
      window.spellPanel:ensureChildVisible(input)
    end
    s.moveDown.onClick = function(self)
      local input = self:getParent()
      local index = window.spellPanel:getChildIndex(input)
      if index >= window.spellPanel:getChildCount() then return end
      local t = storage.custom.kill_rabbit.spells
      t[index],t[index+1] = t[index+1], t[index]
      window.spellPanel:moveChildToIndex(input, index + 1)
      window.spellPanel:ensureChildVisible(input)
    end
    s.onDoubleClick = function(self)
      s:destroy()
      table.removevalue(storage.custom.kill_rabbit.spells, value)
      window.things.spell:setText(value.spell)
      window.things.cooldown:setText(value.cd)
      storage.custom.kill_rabbit.distance = value.dist
      colorizeDistance()
    end
  end
  storage.custom.kill_rabbit.distance = 10
  window.things.spell:setText()
  window.things.cooldown:setText()
  colorizeDistance()
end

reloadSpellPanel()

window.things.add.onClick = function(self)
  local name = window.things.spell:getText()
  local cooldown = tonumber(window.things.cooldown:getText())
  local distance = storage.custom.kill_rabbit.distance
  if (not name) or (not cooldown) or (not distance) then return warn("Algo deu errado.") end
  table.insert(storage.custom.kill_rabbit.spells, {index = #window.spellPanel:getChildren(), spell = name, cd = cooldown, dist = distance, enabled = true})
  reloadSpellPanel()
end