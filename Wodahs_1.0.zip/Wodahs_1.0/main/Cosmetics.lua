storage.custom.cosmWindow = storage.custom.cosmWindow or {type = "min", enabled = false, position = {x=0,y=0}}
local cosmMini = setupUI([[
ShaderSourceBoxPopupMenu < ComboBoxPopupMenu
ShaderSourceBoxPopupMenuButton < ComboBoxPopupMenuButton
ShaderSourceBox < ComboBox
  @onSetup: |
    self:addOption("Blue")
    self:addOption("Green")
    self:addOption("Yellow")
    self:addOption("Red")
    self:addOption("Light Blue")
    self:addOption("Purple")
    self:addOption("White")

MiniWindow
  font: verdana-11px-rounded
  id: misc
  !text: tr('Cosmetics')
  icon: /bot/Wodahs_1.0/main/icon.png
  icon-size: 10 10
  icon-offset: 3 3
  @onClose: modules.game_bot.onMiniWindowClose()
  &save: true
  &autoOpen: 10
  image-source:
  opacity: 0.8
  background-color: black
  visible: false

  MiniWindowContents

    BotSwitch
      id: walk_effect
      text: Walk-Effect
      anchors.left: parent.left
      anchors.right: parent.right
      anchors.top: parent.top

    HorizontalScrollBar
      id: walk_effect_id
      anchors.left:prev.left
      anchors.right: prev.right
      anchors.top: prev.bottom
      margin-top: 5
      minimum: 1
      maximum: 5000
      step: 1

    BotSwitch
      id: outfit
      text: Outfit Changer
      anchors.left: parent.left
      anchors.right: parent.right
      anchors.top: prev.bottom
      margin-top: 5

    HorizontalScrollBar
      id: outfit_id
      anchors.left:prev.left
      anchors.right: prev.right
      anchors.top: prev.bottom
      margin-top: 5
      minimum: 1
      maximum: 10000
      step: 1
    BotSwitch
      id: shader
      text: Shaders
      anchors.left: parent.left
      anchors.right: parent.right
      anchors.top: prev.bottom
      margin-top: 5

    ShaderSourceBox
      id: shader_id
      anchors.left:prev.left
      anchors.right: prev.right
      anchors.top: prev.bottom
      margin-top: 5



]], modules.game_interface.getLeftPanel())
cosmMini:setId("cosmMini")

cosmMini:setVisible(storage.custom.cosmWindow.enabled or false)
if storage.custom.cosmWindow.type == "min" then
  cosmMini:minimize()
else
  cosmMini:maximize()
end

local shaders = {
  ["Light Blue"] = "ShaderLightBlueStatic",
  ["Blue"] = "ShaderBlueStatic",
  ["Red"] = "ShaderRedStatic",
  ["Purple"] = "ShaderPurpleStatic",
  ["White"] = "ShaderWhiteStatic",
  ["Green"] = "ShaderGreenStatic",
  ["Yellow"] = "ShaderYellowStatic",

}

--miscMini:minimize()
cosmMini:setPosition({x=storage.custom.cosmWindow.position.x,y=storage.custom.cosmWindow.position.y} or {x=0,y=0})

cosmMini.closeButton:setImageColor("red")
cosmMini.minimizeButton:setImageColor("#00FFFF")
cosmMini.lockButton:setImageColor("yellow")

cosmMini.minimizeButton.onClick = function(self)
  if self:isOn() then
    cosmMini:maximize()
    storage.custom.cosmWindow.type = "max"
  else
    cosmMini:minimize()
    storage.custom.cosmWindow.type = "min"
  end

end

cosmMini.lockButton.onClick = function(self)
  if cosmMini:isDraggable() then
    cosmMini:lock()
  else
    cosmMini:unlock()
  end
end

cosmMini.closeButton.onClick = function(self)
  storage.custom.cosmWindow.enabled = not storage.custom.cosmWindow.enabled

  cosmMini:hide()
end

importStyle("/main/myscroll.otui")
cosmMini.miniwindowScrollBar:setStyle("MyVerticalScrollBar")
cosmMini.miniwindowScrollBar.incrementButton:setWidth(5)
cosmMini.miniwindowScrollBar.decrementButton:setWidth(5)
cosmMini.miniwindowScrollBar.sliderButton:setWidth(3)
cosmMini.miniwindowScrollBar.sliderButton:setImageSource()
cosmMini.miniwindowScrollBar.sliderButton:setBackgroundColor("#757575")
local function miscMovable()
  cosmMini.onDragEnter = function(widget, mousePos)
    widget:breakAnchors()
    widget:setParent(g_ui.getRootWidget())
    widget.movingReference = { x = mousePos.x - widget:getX(), y = mousePos.y - widget:getY() }
    return true
  end
  
  cosmMini.onDragMove = function(widget, mousePos, moved)
    local parentRect = widget:getParent():getRect()
    local x = math.min(math.max(parentRect.x, mousePos.x - widget.movingReference.x), parentRect.x + parentRect.width - widget:getWidth())
    local y = math.min(math.max(parentRect.y - widget:getParent():getMarginTop(), mousePos.y - widget.movingReference.y), parentRect.y + parentRect.height - widget:getHeight())        
    widget:move(x, y)
    widget:setBorderWidth(1)
    widget:setBorderColor("teal")
    return true
  end
  
  cosmMini.onDragLeave = function(widget, pos)
    storage.custom.cosmWindow.position.x = widget:getX();
    storage.custom.cosmWindow.position.y = widget:getY();

    widget:setBorderWidth(0)
    return true
  end
end

miscMovable()

storage.custom.walk_effect = storage.custom.walk_effect or {id=0, enabled=false}

cosmMini.contentsPanel.walk_effect.onClick = function(self)
  storage.custom.walk_effect.enabled = not storage.custom.walk_effect.enabled
  self:setOn(storage.custom.walk_effect.enabled)
end
cosmMini.contentsPanel.walk_effect:setOn(storage.custom.walk_effect.enabled)

cosmMini.contentsPanel.walk_effect_id.onValueChange = function(self, value)
  storage.custom.walk_effect.id = value
  self.valueLabel:setText(value)
end

cosmMini.contentsPanel.walk_effect_id.valueLabel:setText(storage.custom.walk_effect.id)

onPlayerPositionChange(function(oldpos, newpos)
  if not storage.custom.walk_effect.enabled then return end
  if not fxx then
      fxx = Effect.create()
      if fxx then
          fxx:setId(storage.custom.walk_effect.id)
          g_map.addThing(fxx, pos())
          fxx = nil
      end
  end
end)

storage.custom.outfitChanger = storage.custom.outfitChanger or {id=0, enabled=false}

cosmMini.contentsPanel.outfit:setOn(storage.custom.outfitChanger.enabled)
cosmMini.contentsPanel.outfit_id.valueLabel:setText(storage.custom.outfitChanger.id)
cosmMini.contentsPanel.outfit.onClick = function(self)
  storage.custom.outfitChanger.enabled = not storage.custom.outfitChanger.enabled
  self:setOn(storage.custom.outfitChanger.enabled)
end

cosmMini.contentsPanel.outfit_id.onValueChange = function(self, value)
  storage.custom.outfitChanger.id = value
  self.valueLabel:setText(value)
end

local function changeOutfit()
  if not storage.custom.outfitChanger.enabled then return end
  if storage.custom.outfitChanger.id == 0 then return end
  if player:getOutfit().type ~= storage.custom.outfitChanger.id then
    player:setOutfit({type = storage.custom.outfitChanger.id})
    player:setOutfitShader(shaders[storage.custom.shader.shader])
  end
end
macro(1, function() changeOutfit() end)

--- shaders

storage.custom.shader = storage.custom.shader or {enabled=false, shader="Blue"}

cosmMini.contentsPanel.shader_id:setOption(storage.custom.shader.shader)
cosmMini.contentsPanel.shader.onClick = function(self)
  storage.custom.shader.enabled = not storage.custom.shader.enabled
  player:setOutfitShader(shaders[storage.custom.shader.shader])
  self:setOn(storage.custom.shader.enabled)
end
cosmMini.contentsPanel.shader:setOn(storage.custom.shader.enabled)

schedule(150, function()
if storage.custom.shader.enabled then
  player:setOutfitShader(shaders[storage.custom.shader.shader])
end
end)

cosmMini.contentsPanel.shader_id.onOptionChange = function(self, option, data)
  storage.custom.shader.shader = option
  player:setOutfitShader(shaders[option])
end

--macro(1, function() if not storage.custom.shader.enabled then return end; player:setOutfitShader(shaders[storage.custom.shader.shader]) end)
onPlayerPositionChange(function(newpos, oldpos)
  if not storage.custom.shader.enabled then return end;
  if newpos.z ~= oldpos.z then
    player:setOutfitShader(shaders[storage.custom.shader.shader])
  end
end)
local essButton = UI.Button("Cosmetics", function() cosmMini:setVisible(not cosmMini:isVisible()); cosmMini:minimize(); storage.custom.cosmWindow.enabled = not storage.custom.cosmWindow.enabled; end, mainTab)
essButton:setFont("verdana-11px-rounded")