storage.custom.miscWindow = storage.custom.miscWindow or {type = "min", enabled = false, position = {x=0,y=0}}

local miscMini = setupUI([[

MiscButton < BotButton
  anchors.left: parent.left
  anchors.right: parent.right
  anchors.top: prev.bottom
  margin-top: 5
  font: verdana-11px-rounded

MiscSwitch < BotSwitch
  anchors.left: parent.left
  anchors.right: parent.right
  anchors.top: prev.bottom
  margin-top: 5
  font: verdana-11px-rounded

MiniWindow
  font: verdana-11px-rounded
  id: misc
  !text: tr('Miscellaneous')
  icon: /bot/Wodahs_1.0/main/icon.png
  @onClose: modules.game_bot.onMiniWindowClose()
  &save: true
  &autoOpen: 10
  image-source:
  opacity: 0.8
  background-color: black
  visible: false
  icon-size: 10 10
  icon-offset: 3 3

  MiniWindowContents

    BotSwitch
      id: hud
      text: HUD
      anchors.left: parent.left
      anchors.right: parent.right
      anchors.top: parent.top
      font: verdana-11px-rounded

    MiscButton
      id: shell
      text: Shell v1

    MiscButton
      id: editor
      text: Editor
    MiscSwitch
      id: quickloot
      text: QuickLoot
    MiscSwitch
      id: xray
      text: X-RAY
    MiscButton
      id: bestiary
      text: Bestiary
    
]], modules.game_interface.getLeftPanel())
miscMini:setVisible(storage.custom.miscWindow.enabled)

local marshadow = [[
Label
  size: 50 50
  anchors.right: parent.right
  anchors.bottom: parent.bottom
  image-source: /bot/Wodahs_1.0/main/gif
  opacity: 0.6
]]

if not miscMini:recursiveGetChildById("marshadow") then
  local sh = g_ui.loadUIFromString(marshadow, miscMini)
  sh:setId("marshadow")
end

if storage.custom.miscWindow.type == "min" then
  miscMini:minimize()
  miscMini:recursiveGetChildById("marshadow"):hide()
else
  miscMini:maximize()
  miscMini:recursiveGetChildById("marshadow"):show()
end

importStyle("/main/myscroll.otui")
miscMini.miniwindowScrollBar:setStyle("MyVerticalScrollBar")
miscMini.miniwindowScrollBar.incrementButton:setWidth(5)
miscMini.miniwindowScrollBar.decrementButton:setWidth(5)
miscMini.miniwindowScrollBar.sliderButton:setWidth(3)
miscMini.miniwindowScrollBar.sliderButton:setImageSource()
miscMini.miniwindowScrollBar.sliderButton:setBackgroundColor("#757575")

--miscMini:minimize()
miscMini:setPosition({x=storage.custom.miscWindow.position.x,y=storage.custom.miscWindow.position.y} or {x=0,y=0})

miscMini.closeButton:setImageColor("red")
miscMini.minimizeButton:setImageColor("#00FFFF")
miscMini.lockButton:setImageColor("yellow")

miscMini.minimizeButton.onClick = function(self)
  if self:isOn() then
    miscMini:maximize()
    storage.custom.miscWindow.type = "max"
    miscMini:recursiveGetChildById("marshadow"):show()
  else
    miscMini:minimize()
    storage.custom.miscWindow.type = "min"
    miscMini:recursiveGetChildById("marshadow"):hide()
  end
end

miscMini.lockButton.onClick = function(self)
  if miscMini:isDraggable() then
    miscMini:lock()
  else
    miscMini:unlock()
  end
end

miscMini.closeButton.onClick = function(self)
  storage.custom.miscWindow.enabled = not storage.custom.miscWindow.enabled
  miscMini:hide()
end

local function miscMovable()
  miscMini.onDragEnter = function(widget, mousePos)
    widget:breakAnchors()
    widget:setParent(g_ui.getRootWidget())
    widget.movingReference = { x = mousePos.x - widget:getX(), y = mousePos.y - widget:getY() }
    return true
  end
  
  miscMini.onDragMove = function(widget, mousePos, moved)
    local parentRect = widget:getParent():getRect()
    local x = math.min(math.max(parentRect.x, mousePos.x - widget.movingReference.x), parentRect.x + parentRect.width - widget:getWidth())
    local y = math.min(math.max(parentRect.y - widget:getParent():getMarginTop(), mousePos.y - widget.movingReference.y), parentRect.y + parentRect.height - widget:getHeight())        
    widget:move(x, y)
    widget:setBorderWidth(1)
    widget:setBorderColor("teal")
    return true
  end
  
  miscMini.onDragLeave = function(widget, pos)
    storage.custom.miscWindow.position.x = widget:getX();
    storage.custom.miscWindow.position.y = widget:getY();
    widget:setBorderWidth(0)
    return true
  end
end

miscMovable()

local terminal = g_ui.getRootWidget():recursiveGetChildById("termUI")
local shEditor = g_ui.getRootWidget():recursiveGetChildById("shEditor")
miscMini.contentsPanel.shell.onClick = function(self)
  terminal:setVisible(not terminal:isVisible())
  storage.custom.terminal.enabled = not storage.custom.terminal.enabled
end

miscMini.contentsPanel.editor.onClick = function(self)
  shEditor:setVisible(not shEditor:isVisible())
end

local root = g_ui.getRootWidget()
storage.custom.hud = storage.custom.hud or {}
miscMini.contentsPanel.hud.onClick = function(self)
  storage.custom.hud.enabled = not storage.custom.hud.enabled
  self:setOn(storage.custom.hud.enabled)
  root:recursiveGetChildById("tUI"):setVisible(storage.custom.hud.enabled)
  root:recursiveGetChildById("stUI"):setVisible(storage.custom.hud.enabled)
  root:recursiveGetChildById("deathList"):setVisible(storage.custom.hud.enabled)
end

miscMini.contentsPanel.hud:setOn(storage.custom.hud.enabled)


miscMini.contentsPanel.quickloot.onClick = function(self)
  storage.custom.quickloot = not storage.custom.quickloot
  self:setOn(storage.custom.quickloot)
end
miscMini.contentsPanel.quickloot:setOn(storage.custom.quickloot)

local QL = {}


-- quickloot
function QL.click(self)
  info("You quicklooted ".. self:getItem():getId())
  g_game.move(self:getItem(), {x=65535, y=SlotBack, z=0}, self:getItem():getCount())
end

function QL.setup(c)
  if not storage.custom.quickloot then return end
  local window = c.window;
  if not window:getText():lower():find("dead") then return end
  local panel = window:getChildById("contentsPanel");
  for i = 1, c:getCapacity() do
    local slot = panel:getChildren()[i]
    if slot and slot:getItem() then
      slot.onDoubleClick = QL.click
      slot:setTooltip("DoubleClick = QuickLoot")
    end
  end
end
onContainerOpen(QL.setup)


--- walk effect


local miscButton = UI.Button("Miscellaneous", function()
  miscMini:setVisible(not miscMini:isVisible());
  storage.custom.miscWindow.enabled = not storage.custom.miscWindow.enabled;
end, mainTab)

miscButton:setFont("verdana-11px-rounded")


storage.custom.xray = storage.custom.xray or {enabled = false}
miscMini.contentsPanel.xray.onClick = function(self)
  storage.custom.xray.enabled = not storage.custom.xray.enabled
  self:setOn(storage.custom.xray.enabled)
  --print(storage.custom.xray.enabled)
  if not storage.custom.xray.enabled then
    for i, tile in ipairs(g_map.getTiles(posz())) do
      tile:setText()
    end
  end
end

miscMini.contentsPanel.xray:setOn(storage.custom.xray.enabled)

macro(1, function()
  if not storage.custom.xray.enabled then return end

  for _, spec in ipairs(getSpectators(true)) do
      if spec:isPlayer() then
          if spec:getPosition().z > posz() then
              local tile = g_map.getTile({x = spec:getPosition().x, y = spec:getPosition().y, z = posz()})
              if tile then
                  tile:setText(spec:getName().. " [".. posz()-spec:getPosition().z.. "]", "#787878")
              end
          end
      end
  end
end)

onCreaturePositionChange(function(creature, newPos, oldPos)
if creature == player then return end
if type(oldPos) ~= "table" then return end  
    oldPos = {x = oldPos.x, y = oldPos.y, z = posz()}
    local tile = g_map.getTile(oldPos)
    if (tile) then
        tile:setText()
    end
end)


miscMini.contentsPanel.bestiary.onClick = function(self)
  local bestiaryWindow = g_ui.getRootWidget():getChildById("bestiaryUI")
  bestiaryWindow:setVisible(not bestiaryWindow:isVisible())
end