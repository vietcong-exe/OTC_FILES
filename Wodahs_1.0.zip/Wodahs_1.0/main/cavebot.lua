-- Cavebot by otclient@otclient.ovh
-- visit http://bot.otclient.ovh/

local cavebotTab = "Cave"
local targetingTab = "Target"

setDefaultTab(cavebotTab)
CaveBot = {} -- global namespace
CaveBot.Extensions = {}
importStyle("/default/cavebot/cavebot.otui")
importStyle("/default/cavebot/config.otui")
importStyle("/default/cavebot/editor.otui")
importStyle("/default/cavebot/supply.otui")
dofile("/default/cavebot/actions.lua")
dofile("/default/cavebot/config.lua")
dofile("/default/cavebot/editor.lua")
dofile("/default/cavebot/example_functions.lua")
dofile("/default/cavebot/recorder.lua")
dofile("/default/cavebot/walking.lua")
-- in this section you can add extensions, check extension_template.lua
--dofile("/cavebot/extension_template.lua")
dofile("/default/cavebot/depositer.lua")
dofile("/default/cavebot/supply.lua")
-- main cavebot file, must be last
dofile("/default/cavebot/cavebot.lua")

setDefaultTab(targetingTab)
TargetBot = {} -- global namespace
importStyle("/default/targetbot/looting.otui")
importStyle("/default/targetbot/target.otui")
importStyle("/default/targetbot/creature_editor.otui")
dofile("/default/targetbot/creature.lua")
dofile("/default/targetbot/creature_attack.lua")
dofile("/default/targetbot/creature_editor.lua")
dofile("/default/targetbot/creature_priority.lua")
dofile("/default/targetbot/looting.lua")
dofile("/default/targetbot/walking.lua")
-- main targetbot file, must be last
dofile("/default/targetbot/target.lua")
