setDefaultTab("Main")

local marshadow = [[
UIWidget
  size: 50 50
  anchors.right: parent.right
  anchors.bottom: parent.bottom
  image-source: /bot/Wodahs_1.0/main/gif.png
  opacity: 0.6
  tooltip: Marshadow is watching you...
  image-shader: ShaderPurpleStatic
]]

if not modules.game_bot.botWindow:recursiveGetChildById("marshadow") then
  local sh = g_ui.loadUIFromString(marshadow, modules.game_bot.botWindow)
  sh:setId("marshadow")
end

modules.game_bot.botWindow.minimizeButton.onClick = function(self)
  if not self:isOn() then
    modules.game_bot.botWindow:minimize()
    self:getParent():recursiveGetChildById("marshadow"):hide()
  else
    modules.game_bot.botWindow:maximize()
    self:getParent():recursiveGetChildById("marshadow"):show()
  end
end

local function updateBotUI()
  if modules.game_bot.botWindow:getText() == "SADBOY ISSUES" then return; end 
  modules.game_bot.botWindow:setImageSource()
  modules.game_bot.botWindow:setBackgroundColor("black")
  modules.game_bot.botWindow:setOpacity(0.8)
  modules.game_bot.botWindow:setText("SADBOY ISSUES")
  -- modules.game_bot.botWindow:setColor("white")
  -- modules.game_bot.botWindow:setIcon("/bot/Wodahs_1.0/main/icon.png")
  -- modules.game_bot.botWindow:setIconOffset({x=0,y=0})
  -- modules.game_bot.botWindow:setIconSize({width=13, height=13})
  modules.game_bot.botWindow:setFont("verdana-11px-rounded")
  modules.game_bot.botWindow.closeButton:setImageColor("red")
  modules.game_bot.botWindow.minimizeButton:setImageColor("#00FFFF")
  modules.game_bot.botWindow.lockButton:setImageColor("yellow")
  modules.game_bot.botWindow.contentsPanel.botPanel:setMarginTop(10)
  modules.game_bot.botWindow.contentsPanel.config:setMarginLeft()
  modules._G.g_logger.info("Welcome to first-time in your custom. created by dc: spywares")
end


local botMessages = modules.game_bot.botWindow.contentsPanel.messages
botMessages:setFont("verdana-11px-rounded")

local messageLabel = [[
Panel
  height: 18
  Label
    id: icon
    anchors.left: parent.left
    size: 15 15
    anchors.verticalCenter: parent.verticalCenter
    margin-left: 5
    image-source: /bot/Wodahs_1.0/main/icon

  Label
    id: text
    height: 18
    text-align: center
    anchors.fill: parent
    font: my-font
]]
function message(category, msg)
  local widget = g_ui.loadUIFromString(messageLabel, botMessages)
  widget.added = modules._G.g_clock.millis()
  if category == 'error' then
    widget.text:setText(msg)
    widget.text:setColor("red")
    modules._G.g_logger.error("[SHADOW] " .. msg)
  elseif category == 'warn' then
    widget:setText(msg)        
    widget:setColor("yellow")
    modules._G.g_logger.warning("[SHADOW] " .. msg)
  elseif category == 'info' then
    widget:setText(msg)        
    widget:setColor("white")
    modules._G.g_logger.info("[SHADOW] " .. msg)
  elseif category == 'shadow' then
    widget.text:setText(msg)  
    widget.text:setColor("#848482")
    modules._G.g_logger.info("[SHADOW] " .. msg)
  end
  
  if botMessages:getChildCount() > 5 then
    botMessages:getFirstChild():destroy()
  end
end

--updateTabsBorder()
updateBotUI()
function setBrightWhiteGlowColor()
  return "#d3d3d3"
end

local glowPosition = 1
local glowDirection = 1

macro(100, function()
  local text = 'SADBOY ISSUES'
  local coloredText = {}

  local numChars = #text
  local glowRange = math.max(1, math.floor(numChars / 20))

  for i = 1, numChars do
      local char = text:sub(i, i)
      local color = "#757575"
      if math.abs(i - glowPosition) <= glowRange then
          color = setBrightWhiteGlowColor()
      end
      table.insert(coloredText, char)
      table.insert(coloredText, color)
  end

  glowPosition = glowPosition + glowDirection
  if glowPosition > numChars then
      glowPosition = numChars - 1
      glowDirection = -1
  elseif glowPosition < 1 then
      glowPosition = 2
      glowDirection = 1
  end
  modules.game_bot.botWindow:setColoredText(coloredText)
end)



local count = 0
local function removeSeparators()
  for _, i in pairs(modules.game_bot.botWindow.contentsPanel:getChildren()) do
    if count >= 2 then break end
      if i:getStyleName() == "HorizontalSeparator" then
        i:destroy()
        count = count + 1
      end
  end
end
removeSeparators()