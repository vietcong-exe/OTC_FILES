local _C = {
    [1] = { active = true, name = "Makyo Hyosatsu", cooldown = 2.5, distance = 8, value = 0 },
    [2] = { active = true, name = "Hissatsu Hyoso", cooldown = 2, distance = 8, value = 0 },
    [3] = { active = true, name = "Makyo Hakuhyo", cooldown = 1, distance = 8, value = 0 },
    [4] = { active = true, name = "Sensatsu Suisho", cooldown = 0.5, distance = 8, value = 0 },
    [5] = { active = true, name = "Hyoton Shonyuseki", cooldown = 0.5, distance = 8, value = 0 },
    [6] = { active = true, name = "", cooldown = 2.5, distance = 8, value = 0 },
}
local _G = modules._G

function getDistBetween(p1, p2)
    if not p1 or not p2 then return end
    return math.max(math.abs(p1.x - p2.x), math.abs(p1.y - p2.y))
end

function TurnToMicro(seg)
    return seg*1000000
end

local function onPlayerTalk(name, level, mode, text, channelId, pos)
    local player = getCreatureByName(name)
    if not player or player:getId() ~= g_game.getLocalPlayer():getId() then return end

    for _, spell in ipairs(_C) do
        if text:lower():find(spell.name:lower()) then
            spell.value = _G.g_clock.micros() + TurnToMicro(spell.cooldown)
        end
    end
end

onTalk(onPlayerTalk)

공격 = function()
    local target = g_game.getAttackingCreature()
    if not target then return end
    for index, spells in ipairs(_C) do
        if spells.value <= _G.g_clock.micros() then
            if getDistBetween(player:getPosition(), target:getPosition()) < spells.distance then
                say(spells.name)
            end
        end
    end
end

macro(1, "공격", function() 공격() end)
